# Resources

The resources folder contains all of the scripts and CloudFormation templates used in the provisioning of both the static global infrastructure, as well as the tenant-specific bits that are deployed during tenant onboarding and registration.