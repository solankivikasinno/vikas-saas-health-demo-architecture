/*
infrateam and application team
 */
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tenant-detail',
  templateUrl: './tenant-detail.component.html',
  styles: [
  ]
})
export class TenantDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
