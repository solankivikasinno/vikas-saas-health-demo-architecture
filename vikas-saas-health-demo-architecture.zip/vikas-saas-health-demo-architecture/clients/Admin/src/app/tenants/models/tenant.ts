/*
infrateam and application team
 */

export interface Tenant {
  name: string;
  url: string;
}
