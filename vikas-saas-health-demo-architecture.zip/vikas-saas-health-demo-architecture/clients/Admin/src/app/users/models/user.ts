export interface User {
  email: string;
  created?: string;
  modified?: string;
  enabled?: boolean;
  status?: string;
  verified?: boolean;
}
