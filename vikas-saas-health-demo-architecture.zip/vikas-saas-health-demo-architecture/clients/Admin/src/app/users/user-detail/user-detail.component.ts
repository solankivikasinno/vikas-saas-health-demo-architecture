/*
infrateam and application team
 */

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styles: [
  ]
})
export class UserDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
