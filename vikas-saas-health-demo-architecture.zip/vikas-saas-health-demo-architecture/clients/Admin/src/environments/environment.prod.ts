export const environment = {
  production: true,
  clientId: '$APPCLIENTID',
  issuer: '$AUTHSERVERURL',
  customDomain: '$AUTHCUSTOMDOMAIN',
  apiUrl: 'https://api.$CUSTOM_DOMAIN',
  domain: '$CUSTOM_DOMAIN',
};
