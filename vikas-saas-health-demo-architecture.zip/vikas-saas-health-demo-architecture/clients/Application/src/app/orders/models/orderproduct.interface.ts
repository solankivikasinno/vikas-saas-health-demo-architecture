/*
infrateam and application team
 */
export interface OrderProduct {
  productId: string;
  price: number;
  quantity: number;
}
