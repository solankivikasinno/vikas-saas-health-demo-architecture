/*
infrateam and application team
 */
export interface Product {
  productId: string;
  name: string;
  price: number;
  pictureUrl?: string;

}
