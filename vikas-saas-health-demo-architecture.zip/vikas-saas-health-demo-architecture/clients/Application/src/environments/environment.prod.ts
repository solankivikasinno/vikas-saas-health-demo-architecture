export const environment = {
  production: true,
  apiUrl: 'https://api.eks-ref-arch.com',
  domain: 'eks-ref-arch.com',
};
